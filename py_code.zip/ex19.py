function = {
    "name":"operator",
    "class" :"arithmetic",
    "number": 12
    }