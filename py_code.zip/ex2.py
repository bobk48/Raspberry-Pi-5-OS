print("Count for me, Python!")
for n in range (5):
      print("I’m counting!", n)
print("I’m done counting!")
