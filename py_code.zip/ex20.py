def generadd(Q):
     for i in range(Q):
         yield i       #generates the next value
         i += 1