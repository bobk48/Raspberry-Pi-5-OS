w = 36
y = 13
z = 20
if w < 37:
    print ("w is less than 37")
    if y > 13:
        print ("y is greater than 13")
    elif y == 13:
        print ("y is equal to 13")
    else:
        print ("y is less than 13")
    if z > 21:
        print ("z is greater than 21")
    elif z == 21:
        print ("z is equal to 21")
    else:
        print ("z is less than 21")
else:
    print ("w is greater than or equal to 37")
