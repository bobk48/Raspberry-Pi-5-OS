s= int(input("Enter an Integer"))
i = 0
numbers = []
while i < s:
      numbers.append(i)
      i = i + 1
      print ("numbers now: ", numbers)