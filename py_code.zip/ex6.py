x = 27
if x == 0:   # the == is a logical, or Boolean operator
         print ("x equal 0")
elif x == 1: #one or more of these optional blocks are allowed
         print ("x equal 1")
else:        #the optional block
         print ("x is something else")