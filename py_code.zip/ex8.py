limit = [1, 2, 3, 4, 5]
for number in limit:
    print ("number of repeats %d" % number)