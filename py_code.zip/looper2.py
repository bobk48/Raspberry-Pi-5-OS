print("Count for me, Python")
for n in range(7):
    print("I'm counting!",n)
print("I'm done counting!")