#! /usr/bin/env python3
print("Loop starting!")
for i in range(12):
    print("Loop number is",i)
print("Loop finished!")
